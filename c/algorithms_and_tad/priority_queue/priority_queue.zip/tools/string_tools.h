#ifndef WORD_REPLACE_STRING_REPLACER_H
#define WORD_REPLACE_STRING_REPLACER_H

// Scans a single line from stdin, ending in \n or \r characters, as well as returning allocated pointer
char *scan_word();

#endif
