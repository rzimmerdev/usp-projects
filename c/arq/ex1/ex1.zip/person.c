#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "scanner.h"


typedef struct Person_t {

    char first_name[51];
    char last_name[51];
    char email[81];
    char nationality[51];
    int age;

} person;


int person_size() {
    int struct_size =
            sizeof((person *)0)->first_name +
            sizeof((person *)0)->last_name +
            sizeof((person *)0)->email +
            sizeof((person *)0)->nationality +
            sizeof(int);

    return struct_size;
}



void print_person(person *to_print) {

    printf("%s\n%s\n%s\n%s\n%d\n",
           to_print->first_name,
           to_print->last_name,
           to_print->email,
           to_print->nationality,
           to_print->age
    );
}


person *scan_person() {

    person *new_person = malloc(sizeof(person));

    scan_fixed(new_person->first_name);
    scan_fixed(new_person->last_name);
    scan_fixed(new_person->email);
    scan_fixed(new_person->nationality);
    scanf("%d ", &(new_person->age));

    return new_person;
}


person *read_person(FILE *fp) {
    person *new_person = malloc(sizeof(person));

    read_fixed(new_person->first_name, sizeof(new_person->first_name), fp);
    read_fixed(new_person->last_name, sizeof(new_person->last_name), fp);
    read_fixed(new_person->email, sizeof(new_person->email), fp);
    read_fixed(new_person->nationality, sizeof(new_person->nationality), fp);
    fread(&new_person->age, sizeof(int), 1, fp);

    return new_person;
}


void write_person(person *new_person, FILE *fp) {

    write_fixed(new_person->first_name, sizeof(new_person->first_name), fp);
    write_fixed(new_person->last_name, sizeof(new_person->last_name), fp);
    write_fixed(new_person->email, sizeof(new_person->email), fp);
    write_fixed(new_person->nationality, sizeof(new_person->nationality), fp);
    fwrite(&(new_person->age), sizeof(int), 1, fp);
}


int get_total_registers(FILE *fp) {

    fseek(fp, 0, SEEK_END);
    int num_registers = ftell(fp) / person_size();
    fseek(fp, 0, SEEK_SET);

    return num_registers;
}