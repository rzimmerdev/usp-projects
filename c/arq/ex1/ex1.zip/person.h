//
// Created by rzimmerdev on 27/04/2022.
//
#include <stdio.h>

#ifndef ARQ_PERSON_H
#define ARQ_PERSON_H

typedef struct Person_t person;
int person_size();
void print_person(person *to_print);


person *scan_person();
person *read_person(FILE *fp);

void write_str(char *field_pointer, int total_size, FILE *fp);
void write_person(person *new_person, FILE *fp);

int get_total_registers(FILE *fp);

#endif //ARQ_PERSON_H
