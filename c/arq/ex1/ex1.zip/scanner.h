//
// Created by rzimmerdev on 24/04/2022.
//
#include <stdio.h>

#ifndef ARQ_SCANNER_H
#define ARQ_SCANNER_H

char *scan_word();
void scan_fixed(char *word);

void read_fixed(char* word, int total_size, FILE *fp);

void write_fixed(char *field_pointer, int total_size, FILE *fp);

#endif //ARQ_SCANNER_H
