//
// Created by rzimmerdev on 24/11/2021.
//

#ifndef USP_PROJECTS_BINARY_SEARCH_H
#define USP_PROJECTS_BINARY_SEARCH_H

int binary_search(int *array, int higher, int lower, int value);

#endif //USP_PROJECTS_BINARY_SEARCH_H
